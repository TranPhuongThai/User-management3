<?php
define('ACCESS_TOKEN_LIFE_TIME_EXPIRES_IN', 30 * 24 * 60 * 60); // 30 days * 24h * 60m * 60s
define('ACCESS_TOKEN_PREFIX', 'GNV');